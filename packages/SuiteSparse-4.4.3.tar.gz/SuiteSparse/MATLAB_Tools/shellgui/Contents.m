% SHELLGUI
%
% Files
%   shellgui - GUI interface for seashell function
%   seashell - draws a pretty seashell, using a 3D parametric surface.
%

% Example
%   shellgui
